# -*- coding: UTF-8 -*-

from hostloc import start

if __name__ == "__main__":
    start()
